echo "Enter Project Name"
read projectname

mkdir $projectname #root folder
echo "Root Folder created..."
cp index.html $projectname/index.html
echo "Index file has been created..."

cd $projectname
mkdir Pages
echo "Pages Folder has been created..."
mkdir Images
echo "Images Folder has been created..."
mkdir CSS
echo "CSS Folder has been created..."
cd CSS
cp ../../main.css main.css
echo "Main.css File has been created..."
cd ../
mkdir Scripts
echo "Scripts folder has been created..."
mkdir Documentation
echo "Documentation Folder has been created..."
cd Documentation
cp ../../readme.txt readme.txt
echo "Read me file has been created..."
cd ../
mkdir Others
echo "Others folder has been created..."

echo "Project files has been succesfully Created"
