Sindh Madressatul Islam University
Computer Science Department
Operating System
File based Project
by
Arslan Arshad (CSC-17F-050)
Muhammad Muneeb (CSC-17F-049)
Submitted to
Sir Mansoor Ahmed Khoro
